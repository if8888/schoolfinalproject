<?php 
session_start();
include ('Config/db_connect.php');
//$_SESSION['cart']= $_POST['add_to_list'];

if (isset($_POST['add_to_list'])) {
  if(isset($_SESSION['cart'])){
    $session_array_id = array_column($_SESSION['cart'], 'id');

    if(!in_array($_GET['id'], $session_array_id)) {
      $session_array = array(
      'id' => $_GET['id'],
      'course_name' => $_POST['course_name'],
      'course_credit' => $_POST['course_credit']

    );
    $_SESSION['cart'][]= $session_array;
    }
  }else{
    $session_array = array(
      'id' => $_GET['id'],
      'course_name' => $_POST['course_name'],
      'course_credit' => $_POST['course_credit']

    );
    $_SESSION['cart'][]= $session_array;
  }
  //);
}
//include ('logout.php');
?>

<!DOCTYPE html>
<html>
<head>
  <title>Enroll Courses</title>
  <style>
   <link rel="stylesheet" type="text/css" href= "https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
  </style>
</head>
<body>
  <div class="container-fluid">
    <div class="col-sm-12">
      <div class="row">
        <div class="col-sm-6">
          <h2 class="text-center">Available Courses</h2>
           <div class="col-sm-12">
            <div class="row" >
              <div class="">
              </div>
            </div>
              <?php
        $query = "SELECT * FROM courses";
        $result = mysqli_query ($conn, $query);

        while ($row = mysqli_fetch_array($result)) {?>
            <div class = "col-sm-4">
          <form method="post" action="courses.php?id=<?=$row['id']?>">
            <h5 class ='text-center'>Course Name:<?=$row['course_name'];?></h5>
            <h5 class ='text-center' >Course Credit:<?=$row['course_credit'];?></h5>
            <input type="hidden" name="course_name" value="<?=$row['course_name']?>">
             <input type="hidden" name="course_credit" value="<?=$row['course_credit']?>">
            <input type="submit" name="add_to_list" class="btn btn-warning btn-block" value="Add">
            
          </form>

            </div>
          <?php } 
            ?>
          </div>
        <div class="col-sm-6">
          <h2 class="text-center"> Courses Selected</h2>
          <?php

          //var_dump($_SESSION['cart']);
          $output = "";
          $output ="

          <table class='table table-bordered table-striped'> 
            <tr>
            <th> ID </th>
            <th> Course Name </th>
            <th> Course Credit </th>
            <th> Action </th>
            </tr> ";

            if(!empty($_SESSION['cart'])) {
              foreach ($_SESSION['cart'] as $key => $value ){
                $output .="

                <tr>
                  <td>".$value['id']."</td>
                  <td>".$value['course_name']."</td>
                  <td>".$value['course_credit']."</td>
                  
                  <td>
                    <a href = 'courses.php?action = remove&id=" .$value['id']." '>
                    <button class='btn btn-danger btn-block'>Remove</button>
                    </a>
                  </td>
                </tr>
                  ";
              }
            }
          
            echo $output;
          ?>


        </div>
        
      </div>
      
    </div>
    
  </div>
</div>
  <?php
  if(isset($_GET['action'])){

    if ($_GET['action'] == "remove"){
      foreach ($_SESSION['cart'] as $key => $value) {
        if($value['id'] == $_GET['id']) {
          unset($_SESSION['cart'][$key]);


          }
        }
      }
    }
  
  ?>
</body>
</html>