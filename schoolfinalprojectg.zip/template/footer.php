
<style>
	
.footer {
  background-color: #F1F1F1;
  text-align: center;
  padding: 10px;
}
	
</style>
<footer>

<h5> Copyright 2021</h5>
</footer>
</body>