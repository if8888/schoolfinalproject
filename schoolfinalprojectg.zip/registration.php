

<!DOCTYPE html>
<html>
<style >
	<body>
	* {box-sizing: border-box}

/* Full-width input fields */
  input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
    width: 100%;
  }
}
	 </body>
</style>
<head>
	<title>School Final Project </title>
</head>
<body>
	

<div>
	<form action="registration.php" method='post' style="border:1px solid #ccc"> 
		
		<div class="container">
			<h2> Registration</h2>
			
			
			<label for="first_name"><b>First Name</b></label>
			<input type="text" name="first_name" required >

			<label for="last_name"><b>Last Name</b></label>
			<input type="text" name="last_name" required>

			<label for="user_id"><b>User ID</b></label>
			<input type="text" name="user_id" required>

			<label for="password"><b>Password</b></label>
			<input type="password" name="password" required>

			<label for="phone"><b>Phone Number</b></label>
			<input type="text" name="phone" required>

			<label for="email"><b>Email Address</b></label>
			<input type="email" name="email" required > <br \>
			
      <button type="submit" class="submit">Submit</button>
      <p> Already a user? <a href="login.php"><b>Login<b></a></p>
     
			</div>
		</div>
		<div> 
			<?php
			 include ("Config/db_connect.php");
			session_start();
			
		$first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
		$email = mysqli_real_escape_string($conn, $_POST['email']);
		$phone = mysqli_real_escape_string($conn, $_POST['phone']);
		$user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
		$password = mysqli_real_escape_string($conn, $_POST['password']);
		$last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
$query = "INSERT INTO students (first_name, email, phone ,user_id, password, last_name) VALUES ('$first_name', '$email', '$phone', '$user_id','$password','$last_name')";
	if ( mysqli_query($conn, $query)){
	print_r($query);
	header ("Locattion: courses.php");
			}else{echo "error";}
			?>
		</div>
	</form>
	
</div>
</body>
</html>