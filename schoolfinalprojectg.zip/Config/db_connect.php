<?php
$conn = mysqli_connect('localhost', 'ivy', '1234', 'schoolfinal');
if(!$conn){
	echo "Connection Error:". mysqli_connect_error();
}
?>