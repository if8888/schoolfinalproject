
<?php include ("Config/db_connect.php"); ?>

<!DOCTYPE html>
<html>
<style >
	<body>
	* {box-sizing: border-box}

/* Full-width input fields */
  input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
/*.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
/*.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
/*@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
    width: 100%;
  }
}
	 </body>
</style>
<head>
	<title>School Final Project</title>
	
</head>
<body>
	
<div>
	<form action="login.php" method="post" style="border:1px solid #ccc">
		<div class="container">
			<h2>Login</h2>
			
			<label for="user_id"><b>User ID</b></label>
			<input type="text" name="user_id" required>

			<label for="password"><b>Password</b></label>
			<input type="password" name="password" required >
	
      
      <button type="submit" class="submit">Login</button>
      <p>Not a user? <a href="registration.php"><b> Regist Here<b></a></p>
			</div>

			<?php
			
		
		$user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
		$password = mysqli_real_escape_string($conn, $_POST['password']);
		$q = "SELECT * FROM students WHERE user_id = '$user_id' AND password = '$password'";
		$r = mysqli_query($conn, $q);
		$n = mysqli_num_rows($r);
		if ($n == 1){ echo "welcome " . $user_id;
			//header('Location: courses.php' );
		}else {
			header('Location:registration.php');
		}
		?>
	</form>
</div>
</body>
</html>