

<!DOCTYPE html>
<html>
<head>
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial;
  padding: 10px;
  background: #f1f1f1;
}

/* Header/Blog Title */
.header {
  padding: 30px;
  text-align: center;
  background: white;
background-image: url('school2.jpg');
}

.header h1 {
  font-size: 50px;
}

/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #333;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;

  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create two unequal columns that floats next to each other */
/* Left column */
.leftcolumn {   
  float: left;
  width: 75%;
}

table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  text-align: center;
padding: 10px;
 }
  h2 {text-align: center;}



/* Right column */
.rightcolumn {
  float: left;
  width: 25%;
  background-color: #f1f1f1;
  padding-left: 20px;
}

/* Fake image */
.fakeimg {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}

/* Add a card effect for articles */
.card {
  background-color: white;
  padding: 20px;
  margin-top: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Footer */
.footer {
  padding: 20px;
  text-align: center;
  background: #ddd;
  margin-top: 20px;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 800px) {
  .leftcolumn, .rightcolumn {   
    width: 100%;
    padding: 0;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .topnav a {
    float: none;
    width: 100%;
  }
}
</style>
</head>
<body>

<div class="header">
  <h1>Online Courses Registration</h1>

  <p>final school project by Ivy Fu</p>
</div>

<div class="topnav" style="font-size: 50px;">
  <a href="registration.php"><b>Register<b></a>
  <a href="login.php"><b>Login<b></a>
  <a href="courses.php"><b>Courses<b></a>
   <img src="logo.jpg" style="float:right" >
</div>

<div class="row">
  <div class="leftcolumn">
    <div class="card">
      <h2>2021 Spring</h2>
      <h5>2021 Sping Semester Registration </h5>
      <table style="width:1200px">
      <tr>
     <th colspan="3">Spring</th>
	 </tr>
     <tr>
    <td>Math</td>
    <td>English</td>
    <td>Science</td>
	</tr>
	<tr>
    <td>Music</td>
    <td>Art</td>
    <td>Computer</td>
	</tr>
	<tr>
 	<td>Accounting</td>
	<td>Bioligy</td>
	<td>Business</td>
	</tr>
	</table>
      
      <p>Registration dates: Nov. 15 2020 to Jan. 09 2021</p>
      <p> Register/Login, then regist courses.</p>
    </div>
    <div class="card">
      <h2> 2021 Summer</h2>
      <h5>2021 Summer Semester Registration</h5>
       <table style="width:1200px">
      <tr>
     <th colspan="3">Summer</th>
	 </tr>
     <tr>
    <td>Math</td>
    <td>English</td>
    <td>Science</td>
	</tr>
	<tr>
    <td>Music</td>
    <td>Art</td>
    <td>Computer</td>
	</tr>
	<tr>
 	<td>Accounting</td>
	<td>Bioligy</td>
	<td>Business</td>
	</tr>
	</table>
      
      

      <p>Registration dates: May. 15 2020 to June. 09 2021</p>
      <p>Register/Login, then regist courses.</p>
    </div>
     <div class="card">
      <h2>2021 Fall</h2>
      <h5>2021 Fall Semester Registration </h5>
       <table style="width:1200px">
      <tr>
     <th colspan="3">Fall</th>
	 </tr>
     <tr>
    <td>Math</td>
    <td>English</td>
    <td>Science</td>
	</tr>
	<tr>
    <td>Music</td>
    <td>Art</td>
    <td>Computer</td>
	</tr>
	<tr>
 	<td>Accounting</td>
	<td>Bioligy</td>
	<td>Business</td>
	</tr>
	</table>
      <p>Registration dates: July. 15 2020 to Setp. 09 2021</p>
      <p>Register/Login, then regist courses.</p>
    </div>
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>About School</h2>
      <img src="school.jpg"  width="300" height="128";>
      
      <p>The University of Arizona (Arizona, U of A, UArizona, or UA) is a public land-grant research university in Tucson, Arizona. Founded in 1885 by the 13th Arizona Territorial Legislature, the U of A was the first university in the Arizona Territory.</p>
    </div>
    <div class="card">
      <h3>Website</h3>
      <a href="https://www.arizona.edu/">University of Arizona</a>
     
    </div>
    <div class="card">
      <h3>Contack us</h3>
      <p>The University of Arizona | Tucson, Arizona 85721 | 520-621-2211</p>
    </div>
  </div>
</div>

<div class="footer">
  <h2>Unversity Arizona Global Campus, copy right 2021</h2>
</div>

</body>
</html>
